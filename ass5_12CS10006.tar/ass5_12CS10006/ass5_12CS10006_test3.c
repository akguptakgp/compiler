/*************************       Compilers Laboratory Assignment 5             ****************************/
/************************      Written by:Ankit Kumar Gupta (12CS10006)        ***************************/
/************************          Intermediate Code Generation                **************************/    

/***********************       Test file to test Intermediate Code Generation  *************************/
/***********************       this test file focus on testing statements    ************************/   

int a;
int c;
double x;
int i;
double s;
int add1(double a)
{



}
int main()
{

if(i>3) c=3;
if(i<=0) c=x;
else c=x;

while(i>0)
{
a=c+a;
i++;
a--;
}

for(i=0;i>0;i++)
{
c=a+s*3;
s=c;
s--;
c=a;
}

do{
c=a+s*3;
s=c;
c=a;
c--;
a=a+c;
}while(a>0);

while(i)
{
a=c+a;
i++;
}

for(i=0;i;i++)
{
c=a+s*3;
s=c;
c=a;
}

do{
c=a+s*3;
s=c;
c=a;
a=a+c;
}while(a);

return a;
}
