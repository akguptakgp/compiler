/* Compliler Laboratory Assignment 4
   Test file to test Parser it parses input from this ass3_12CS10006_test.c 
 /*  // and it generates syntex error if parsing is not possible
 created by : Ankit Kumar Gupta
*/

//  function to test 

//this test file checks all the functionality that tiny C supports

static int a=9;
extern int b=3; 
void quicksort(int i,int j,int k);  // a simple function declaration quick sort algorithm

int main(){                      // function starts
  int x[20],size,j;  
   float f=0.0=0=.0=7.;            // to check const_float   
 // char c='d','hkhk';			// to check const_char
  int i=0,j=6=6768=57;                     // check const_int 

  printf("Enter size of the array: ");  // check string literal functionality
  scanf("%d",&size);     //Punctuators and identifiers

  printf("Enter %d elements: ",size);
  for(i=0;i<size;i++)
  if(4>0)
    scanf("%d",&x[i]);              
  else
   printf("djkf");
  quicksort(x,0,size-1);

  printf("Sorted elements: ");
  for(i=0;i<size;i++)
    printf(" %d",x[i]);

  return 0;
}


inline void fun(int z)
{ 
  const signed int c=3;
  if(f==g)
   d='3';
  double hg=4.3434=57.67e345=-546.67E4; 
  do
{  
 int a=9;
}while(z);
  switch(c)
{
case 0:
   break;
}
}
#define syntex error // this is a syntex error

